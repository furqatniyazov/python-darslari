# Foydalanuvchidan 2 ta son kiritishni so'rang.
# Agar ikki son bir-biriga teng bo'lsa,
# "Sonlar teng" ekan degan yozuvni konsolga chiqaring.

son1 = int(input("Birinchi sonni kiriting: "))
son2 = int(input("Ikkinchi sonni kiriting: "))

if son1 == son2:
    print("Sonlar teng ekan!")
    