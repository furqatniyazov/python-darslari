# Foydalanuvchidan istalgan son kiritishni so'rang.
# Agar son manfiy bo'lsa konsolga "Manfiy son",
# agar musbat bo'lsa "Musbat son" degan xabarni chiqaring.

if int(input("Son kiriting: ")) < 0:
    print("Manfiy son")
else:
    print("Musbat son")