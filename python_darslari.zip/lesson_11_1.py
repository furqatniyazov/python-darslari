# Foydalanuvchidan juft son kiritishni so'rang.
# Agar foydalanuvchi juft son kiritsa "Rahmat!",
# agar toq son kiritsa "Bu son juft emas" degan xabarni chiqaring.

if int(input("Juft son kiriting: ")) % 2 == 0:
    print("Rahmat!")
else:
    print("Bu juft son emas!")