#Quyidagi matnni aynan shunday ko'rinishda konsolda chiqaring:
import math

print("1. \"Nexia\", \"Tico\", 'Damas' ko'rganlar qilar havas\n")


# 5 ning 4-darajasini toping
print(f"2. 5ning 4chi darajasi {5 ** 4}\n")


# 22 ni 4 ga bo'lganda qancha qoldiq qoladi?
print(f"3. 22ni 4ga bo'lganda {22 % 4} qoldiq qoladi\n")


# Tomonlari 125 ga teng kvadratning yuzi va perimetrini toping
print(f"4. a=125\nyuzi: {125 ** 2}\nperimetri: {(125 * 2) * 2}\n")


# Diametri 12ga teng bo'lgan doiraning yuzini toping (π = 3.14 deb oling)
print(f"5. doira yuzi: {3.14 * (12 / 2) ** 2}\n")

# Katetlari 6 va 7 bo'lgan to'g'ri burchakli uchburchakning gipotenuzasini toping (Pifagor teoremasidan foydalaning)
print(f"6. gipotenuza: {math.sqrt(6 ** 2 + 7 ** 2)}\n")