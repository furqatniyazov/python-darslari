# Foydalanuvchi kiritgan sonning kvadrati va kubini konsolga chiqaruvchi dastur

son = int(input("Istalgan sonni kiriting: "))
print(f"{son}ning kvadrati {son ** 2} ga teng")
print(f"{son}ning kubi {son ** 3} ga teng")
