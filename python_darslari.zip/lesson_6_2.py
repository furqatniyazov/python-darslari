# Foydalanuvchining yoshini so'rab, uning tug'ilgan yilini hisoblab, konsolga chiqaruvchi dastur

yosh = int(input("Yoshingizni kiriting: "))
print(f"Siz {2022-yosh}-yilda tug'ilgansiz")