# Foydalanuvchidan ikki son kiritshni so'rab, kiritilgan sonlarning yig'indisi, ayirmasi, ko'paytmasi va bo'linmasini chiqaruvchi dastur

son1 = float(input("Birinchi sonni kiriting: "))
son2 = float(input("Ikkinchi sonni kiriting: "))

print(f"{son1} + {son2} = {son1 + son2}")
print(f"{son1} - {son2} = {son1 - son2}")
print(f"{son1} * {son2} = {son1 * son2}")
print(f"{son1} / {son2} = {son1 / son2}")