# ismlar degan ro'yxat yarating va kamida 3 ta yaqin do'stingizning ismini kiriting
# Ro'yxatdagi har bir do'stingizga qisqa xabar yozib konsolga chiqaring:

ismlar = ['Mahmud', 'Murod', 'Sherzod']

print(f"Salom {ismlar[0]}, bugun choyxona bormi?")
print(f"{ismlar[1]}, choyxonaga boramizmi?")
print(f"{ismlar[2]} qalesan, choyxonaga soat nechchida kelasan?")