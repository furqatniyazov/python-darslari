# Yuqoridagi ro'yxatdagi sonlar ustida turli arifmetik amallar bajarib ko'ring.
# Ro'yxatdagi ba'zi sonlarning qiymatini o'zgartiring, ba'zilarini esa almashtiring.

sonlar = [12, 42, 33.5, -44, 123, 2.4, -26.4]

print(f"{sonlar[1]} + {sonlar[4]} = {sonlar[1] + sonlar[4]}")
print(f"{sonlar[3]} / {sonlar[2]} = {sonlar[3] / sonlar[2]}")
print(f"{sonlar[2]} * {sonlar[1]} = {sonlar[2] * sonlar[1]}")
print(f"{sonlar[0]} // {sonlar[6]} = {sonlar[0] - sonlar[6]}")
print(f"{sonlar[6]} - {sonlar[5]} = {sonlar[6] // sonlar[5]}")
print(f"{sonlar[5]} ** {sonlar[3]} = {sonlar[5] ** sonlar[3]}")
print(f"{sonlar[1]} % {sonlar[6]} = {sonlar[1] % sonlar[6]}")