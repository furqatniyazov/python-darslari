# t_shaxslar va z_shaxslar degan 2 ta ro'yxat yarating va
# biriga o'zingiz eng ko'p hurmat qilgan tarixiy shaxslarning,
# ikkinchisiga esa zamonamizdagi tirik bo'lgan shaxslarning ismini kiriting.

t_shaxslar = ['Muhammad (s.a.v)', 'Umar r.a.', 'Bilol r.a.', 'al-Buxoriy', 'Amir Temur']
z_shaxslar = ['Zakir Naik', 'Rejeb Tayip Erdogan', 'Shavkat Miromonovich Mirziyoyev']

# Yuqoridagi ro'yxatlarning har biridan bittadan qiymatni sug'urib olib (.pop()), quyidagi ko'rinishda chiqaring:

print(f"Men tarixiy shaxslardan {t_shaxslar.pop(0)} bilan, zamonaviy shaxslardan esa {z_shaxslar.pop(0)} bilan suhbat qilishni istar edim")