# Kamida 5 elementdan iborat ismlar degan ro'yxat tuzing,
# va ro'yxatdagi har bir ismga takrorlanuvchi xabar yozing

ismlar = ["Nursultan", "Fozil", "Furqat", "Akobur", "Farxod"]

for ism in ismlar:
    print(f"Salom, {ism}!\n")

# Yuqoridagi tsikl tugaganidan so'ng, ekranga "Kod n marta takrorlandi" degan xabarni chiqaring (n o'rniga kod necha marta takrorlanganini yozing)

print("Kod", len(ismlar), "marta takrorlandi!")