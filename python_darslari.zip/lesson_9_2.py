# 10 dan 100 gacha bo'lgan toq sonlar ro'yxatini tuzing.
# Ro'yxatning xar bir elementining kubini yangi qatordan konsolga chiqaring.

toq_sonlar = list(range(11, 100, 2))
for son in toq_sonlar:
    print(son ** 3)