# Foydalanuvchidan 5 ta eng sevimli kinolarini kiritshni so'rang,
# va kinolar degan ro'yxatga saqlab oling. Natijani konsolga chiqaring.

kinolar = []
for i in range(0,5):
    kinolar.append(input(f"{i+1}chi eng sevimli kinoingizni kiriting: "))

print("Sevimli kinolar ro'yxati:", kinolar)